#import <UIKit/UIKit.h>

@interface QDGesture : NSObject<NSCoding> {
@private
	NSString *_name;
	NSString *_mode;
    BOOL _handled;
}
@property (nonatomic, readonly) NSString *name;
@property (nonatomic, readonly) NSString *mode;
@property (nonatomic, getter = isHandled) BOOL handled;
+ (id)gestureWithName:(NSString *)name;
+ (id)gestureWithName:(NSString *)name mode:(NSString *)mode;
- (id)initWithName:(NSString *)name;
- (id)initWithName:(NSString *)name mode:(NSString *)mode;
@end

@protocol QDAction;

@interface LibQuickDo : NSObject

@property (nonatomic, readonly) NSArray *actionNames;

+ (LibQuickDo *)sharedInstance;
- (void)addAction:(id<QDAction>)action name:(NSString *)actionName;
- (void)removeAction:(NSString *)actionName;

- (void)handleAction:(NSString *)actionName gesture:(QDGesture *)gesture;

- (void)assignGesture:(QDGesture *)gesture toAction:(NSString *)actionName;
- (void)unassignGesture:(QDGesture *)gesture;
- (NSArray *)gesturesAssignedToAction:(NSString *)actionName;

- (NSString *)actionTitle:(NSString *)actionName;
- (NSString *)actionDescription:(NSString *)actionName;
- (UIImage *)actionIcon:(NSString *)actionName;
@end

@protocol QDAction <NSObject>
@optional
- (void)quickdo:(LibQuickDo *)quickdo handleAction:(QDGesture *)gesture;
@end

@interface QDSettingsViewController : UIViewController <UITableViewDataSource, UITableViewDelegate> {
@protected
    UITableView *_tableView;
	NSString *_actionName;
}
@property (nonatomic, retain) NSString *actionName;
@end

@interface QDModeViewController : QDSettingsViewController {
    NSMutableArray *_modes;
}
@end

@interface QDGestureViewController : QDSettingsViewController {
@protected
	NSString *_mode;
    NSArray *_gestureGroups;
	NSArray *_gestures;
}
@property (nonatomic, retain) NSString *mode;
@end

// Gesture Mode
extern NSString * const QDGestureModeAnywhere;
extern NSString * const QDGestureModeSpringBoard;
extern NSString * const QDGestureModeApplication;
extern NSString * const QDGestureModeLockScreen;

// StatusBar
extern NSString * const QDGestureStatusBarSwipeLeft;
extern NSString * const QDGestureStatusBarSwipeRight;
extern NSString * const QDGestureStatusBarSlideInTopLeft;
extern NSString * const QDGestureStatusBarSlideInTop;
extern NSString * const QDGestureStatusBarSlideInTopRight;
extern NSString * const QDGestureStatusBarHold;
extern NSString * const QDGestureStatusBarTapDouble;
extern NSString * const QDGestureStatusBarTapSingle;

// QuickDoBar
extern NSString * const QDGestureBarSwipeShortLeft;
extern NSString * const QDGestureBarSwipeLongLeft;
extern NSString * const QDGestureBarSwipeShortRight;
extern NSString * const QDGestureBarSwipeLongRight;
extern NSString * const QDGestureBarSwipeLeftUp;
extern NSString * const QDGestureBarSwipeCenterUp;
extern NSString * const QDGestureBarSwipeRightUp;
extern NSString * const QDGestureBarHoldLeft;
extern NSString * const QDGestureBarHoldCenter;
extern NSString * const QDGestureBarHoldRight;
extern NSString * const QDGestureBarDoubleTapLeft;
extern NSString * const QDGestureBarDoubleTapCenter;
extern NSString * const QDGestureBarDoubleTapRight;

// Motion
extern NSString * const QDGestureMotionShake;
extern NSString * const QDGestureMotionShakeTwice;

// Date View
extern NSString * const QDGestureLockScreenDateViewSwipeLeft;
extern NSString * const QDGestureLockScreenDateViewSwipeRight;
extern NSString * const QDGestureLockScreenDateViewSwipeUp;
extern NSString * const QDGestureLockScreenDateViewSwipeDown;
extern NSString * const QDGestureLockScreenDateViewDoubleTap;

// Headset
extern NSString * const QDGestureHeadsetAvailabilityChanged;
extern NSString * const QDGestureHeadsetConnected;
extern NSString * const QDGestureHeadsetDisconnected;

// Volume Button
extern NSString * const QDGestureVolumeDownButtonHoldShort;
extern NSString * const QDGestureVolumeUpButtonHoldShort;
extern NSString * const QDGestureVolumeDownButtonPress;
extern NSString * const QDGestureVolumeUpButtonPress;
extern NSString * const QDGestureVolumeHUDViewSingleTap;
extern NSString * const QDGestureVolumeToggleMuteTwice;

// Menu button
extern NSString * const QDGestureMenuPressSingle;
extern NSString * const QDGestureMenuPressDouble;
extern NSString * const QDGestureMenuPressTriple;
extern NSString * const QDGestureMenuHoldShort;

// Lock button
extern NSString * const QDGestureLockHoldShort;
extern NSString * const QDGestureLockPressDouble;
extern NSString * const QDGestureLockPressSingle;

// Two fingers
extern NSString * const QDGestureTwoFingerSwipeUp;
extern NSString * const QDGestureTwoFingerSwipeDown;
extern NSString * const QDGestureTwoFingerSwipeLeft;
extern NSString * const QDGestureTwoFingerSwipeRight;
extern NSString * const QDGestureTwoFingerPinch;
extern NSString * const QDGestureTwoFingerSpread;
extern NSString * const QDGestureTwoFingerRotateClockwise;
extern NSString * const QDGestureTwoFingerRotateAnticlockwise;
extern NSString * const QDGestureTwoFingerTapDouble;
extern NSString * const QDGestureTwoFingerHold;

// Three fingers
extern NSString * const QDGestureThreeFingerSwipeLeft;
extern NSString * const QDGestureThreeFingerSwipeRight;
extern NSString * const QDGestureThreeFingerSwipeUp;
extern NSString * const QDGestureThreeFingerSwipeDown;
extern NSString * const QDGestureThreeFingerPinch;
extern NSString * const QDGestureThreeFingerSpread;
extern NSString * const QDGestureThreeFingerRotateClockwise;
extern NSString * const QDGestureThreeFingerRotateAnticlockwise;
extern NSString * const QDGestureThreeFingerTapDouble;
extern NSString * const QDGestureThreeFingerHold;
