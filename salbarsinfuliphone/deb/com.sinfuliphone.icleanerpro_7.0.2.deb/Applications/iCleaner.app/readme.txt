_------------------------------------_
_            iCleaner Pro            _
_  http://exile90software.com/cydia  _
 ------------------------------------
The ultimate iPhone, iPod and iPad system cleaner and optimizer! It removes unnecessary files from your device, and allows you to tweak it to your liking.


What does this do?
--------------------------------------
- CLEANUP: iCleaner can remove unnecessary files from your device. The cleanup process is made of the following steps:

1) MESSAGE ATTACHMENTS (disabled by default): it deletes files sent and received via iMessage or MMS. The "smart" setting only deletes files that do not show up in any message, while "on" deletes all attachments (messages with attachments will show a blank icon).

2) SAFARI: it deletes cookies, browsing history and cache files to free up memory and preserve your privacy.

3) APPLICATIONS: it deletes unnecessary AppStore apps caches, cookies, temporary files and snapshots.
Furthermore, it detects popular applications for a more in-depth cleanup. Check the website for info about the supported applications.
More apps are added with each subsequent release. User login data, useful cookies and other relevant files are left untouched. iCleaner only removes the unnecessary.

4) CYDIA: it cleans up Cydia caches and temporary files, unnecessary Cydia applications files, partially downloaded packages and repo files.

5) CYDIA SOURCES (disabled by default): it deletes Cydia sources files. As a result, Cydia will not list any package and the sources will have to be updated. This is disabled by default since it's only helpful if Cydia sources aren't updating correctly.

6) UNUSED DEPENDENCIES (disabled by default): issues the "apt-get autoremove" command in order to remove packages installed as dependencies that are not needed anymore.
Additionally, it removes preference files left by some uninstalled packages and unneeded entries from the "/var/lib/dpkg/status" file.
This is disabled by default since it should only be used by experienced users who want to automate the operation. Note that removed packages and preferences are not included in the "analyze" filesize count.

7) LOG FILES: it deletes log files and crash reports from known locations. These files are generally irrelevant to the user and can be safely deleted.

8) CACHE FILES: it scans and deletes system cache files and databases. Some of them are rebuilt upon respring. This helps removing obsolete cache data.

9) TEMPORARY FILES: it deletes temporary files from your device. These files are meant to be removed automatically, but they often happen not to. iCleaner takes care of that.

10) FILETYPE CLEANUP: iCleaner features a custom cleanup pass based on file extensions. By default, it looks for log and temp files all over the directory tree.
You might want to add more extensions (such as "bak" or "old"), but remember to use this with caution!
Also, note that iCleaner will not allow usage of most non-alphanumeric characters and some disallowed extensions (disallowed ones will be removed as you confirm).

11) CUSTOM FILES AND FOLDERS CLEANUP (disabled by default): with this extremely powerful feature, you can add any file or folder to the cleanup process. Tap on "Add item" to add a new item to the cleanup, or an existing item to edit it.
The possibilities are now endless! Please use this function with caution, as accidentally deleting critical files can force you to restore your device. Keep reading for an explaination of the various configuration fields.

NOTE: you can tap on a specific cleanup step to quickly perform its analysis or cleanup.

######################################

- CUSTOM FILES AND FOLDERS CLEANUP CONFIGURATION FIELDS:

1) PATH: the path to the file or folder to cleanup. You can manually enter it, or tap the magnifying glass button to browse the filesystem.

2) FILE TYPE: here you can choose if the selected file is a regular file or a folder. This field is automatically updated if you use the filesystem browser.

3) FOLDER SETTINGS (only visible if "folder" is selected): "whole folder" deletes the whole folder, "files and subfolders" only deletes files and subfolders contained in the folder, while "only files" only deletes regular files contained in the folder.

4) RECURSIVE (only visible if "files and subfolders" or "only files" is selected): if disabled, the tool will only delete files/folders contained in the folder itself, not inside its subfolders. If enabled, the tool will browse all the subfolders of the selected folder, scanning them for files and/or folders.
This setting is especially useful when combined with the "match" fields.

5) MATCH (only visible if "files and subfolders" or "only files" is selected): these options let you decide which files/folders should be deleted based on their names. "Starting with", "containing" and "ending with" can be used individually or simultaneously to match complex file names.
Matches are case-sensitive. If these fields are empty, iCleaner will match all files and/or folders (depending on how you configured it).


EXAMPLES:
---------

Path: /var/mobile/example.txt
File type: regular file

Deletes the "example.txt" file located in /var/mobile.

---------

Path: /var/mobile/example
File type: folder
Folder setting: whole folder

Deletes the "example" folder located in /var/mobile, with all of its contents.

---------

Path: /var/mobile/example
File type: folder
Folder setting: files and subfolders
Recursive: no (or yes)
Match: n/a

Empties the "example" folder located in /var/mobile, without deleting the folder.
"Recursive" is meaningless here, as it will delete everything inside the folder in both cases (because no "match" option was specified).

---------

Path: /var/mobile/example
File type: folder
Folder setting: files and subfolders
Recursive: no
Match: starting with "cache"

Deletes files and folders with names starting with "cache" inside /var/mobile/example (but not inside its subfolders).

---------

Path: /var/mobile/example
File type: folder
Folder setting: only files
Recursive: yes
Match: containing "crash", ending with ".log"

Deletes files with names containing "crash" and ending with ".log" inside /var/mobile/example and all of its subfolders.
This will delete "aBadcrash1.log", "crash.log", but not "crash.txt" or "pizza.log".

######################################

- ANALYZE: thanks to this feature you can analyze your device and get an estimate of the space that iCleaner can free up for you. Analysis works with the standard cleanup, as well as with every other removal tool.
iCleaner will show a preview of the generated log file upon analysis completion (this allows for quicker display times). You can load the whole file by hitting the "refresh" button in the top right corner.

NOTE: loading the whole file will enable the "search" function.

######################################

- LAUNCH DAEMONS / MOBILESUBSTRATE ADDON / PREFERENCE BUNDLES MANAGEMENT: Daemons are processes that are launched upon system startup (or at a later time) and run in the background.
Disabling some of them may speed up your device by freeing up system resources. Furthermore, you will be able to enable/disable core system functions (such as OTA updates, Game Center, Internet Tethering, VPN and more).

Without too much technicality, MobileSubstrate addons are tweaks you installed via Cydia. You can enable or disable them with a single tap, while still having them installed.
This tool should be mainly used to troubleshoot faulty/incompatible tweaks without having to go through the Cydia install/uninstall process.

Preference Bundles are responsible of displaying preferences for tweaks in the Settings app. Disabling them will make them unavailable, giving you control about which preferences can be actually seen and edited.
The "PreferenceLoader" switch allows you to enable/disable PreferenceLoader. When PreferenceLoader is disabled, you won't be able to view or edit settings of your tweaks inside the Settings app. It acts as a "master switch" for the preference bundles.


NOTE 1: please do NOT use the MobileSubstrate addon manager as a substitution for Cydia uninstallation. You should only use it as a temporary solution to troubleshoot faulty tweaks.

NOTE 2: if you used other daemon management tools, or you manually disabled some of them, please restore daemons to their original configuration before managing them with iCleaner.

NOTE 3: disabled launch daemons are backed up to the "/System/Library/LaunchDaemonsBAK" directory.

NOTE 4: disabled launch daemons, MobileSubstrate addons and Preference Bundles are NOT restored by uninstalling iCleaner. You have to manually enable them before uninstalling it.

NOTE 5: changes made with these tools can be undone even if the device cannot properly boot . If you installed OpenSSH, you will be able to SSH to your device (for a brief timespan) even if it is stuck at the Apple logo.
Just login as "root" from your SSH terminal, then issue the command "icleaner" to trigger iCleaner's command line user interface. From there, you'll be able to restore daemons, Mobile Substrate addons and Preference Bundles to their default state.

######################################

- LANGUAGES / KEYBOARDS/ VOICES ANALYSIS AND REMOVAL: with these tools you can easily remove all of the languages you don't need from your iDevice. Just select the languages you wish to remove, then tap on "Remove languages".
You can remove keyboards (textinput files) and voice control languages as well. These tools will only remove the ones you selected in the "Languages to remove" menu.

NOTE 1: English cannot be removed as a security feature.

NOTE 2: iCleaner will not allow you to delete your own language in most cases, but please double check it. If you remove your own language, and want it back, you'll have to restore your device.

NOTE 3: languages will be installed whenever you install/update apps or tweaks. Therefore, this tool has to be run periodically.

NOTE 4: "keyboards" refer to "international keyboards", the ones you can configure in "Settings - General - Keyboard - International keyboards". They will still appear in the list, but won't work if removed.

######################################

- DICTIONARIES REMOVAL: with this tool you can remove the dictionaries used by the "define" function of your device.

There are many dictionaries you will never use (like the Shogakukan ones, if you don't need Japanese dictionaries). It's a good idea to keep the "Apple Dictionary" installed, in order to have the "define" feature functional.

######################################

- RETINA / NON-RETINA / IPAD / 4" / ITUNESARTWORK IMAGES ANALYSIS AND REMOVAL: these tools allow you to remove device-specific and unnecessary images from your iDevice. For example, iPad images are not needed on iPhone and iPod, and can be safely removed.
Caution is advised with them though, a "Test Mode" run is very recommended (especially when using "remove non-retina images", which can easily break some applications).

iTunesArtwork files are only needed for ad-hoc distribution, display on the AppStore and iTunes library. They serve no purpose on the device. Every app you install has one, and it can be safely removed.
As a result, however, iTunes won't show artworks for apps in the library. If you want to view the artworks, please "transfer your purchases" on iTunes before removing iTunesArtwork files.

iCleaner scans for images in "/Applications/" and "/var/mobile/Applications/". It does not scan the whole disk since that might easily break something on some configurations.

Specific applications can be excluded in the "Excluded apps" menu. The correct procedure for using this function is: running it with "Test Mode" enabled; check all of your apps, to see if any of them has been broken;
restore the backup files; exclude the apps that were broken; finally, run it without test mode.

NOTE 1: please note that deleting images (and languages) will also affect apps .ipa files that are transferred to iTunes. This is especially important if you synchronize your apps to both your iPhone and iPad, as deleting iPad images on your iPhone will break the app on your iPad.
Same story if you have both a 3.5" and a 4" device. To avoid this, it's mandatory that you "transfer your purchases" on iTunes before you use iCleaner to remove images and/or languages.

NOTE 2: 4" refers to 4-inch display devices such as iPhone 5 and iPod Touch 5th gen.

######################################

- WALLPAPERS MANAGEMENT: this tool allows you to remove the stock wallpapers that come with your iOS device. You can tap to see previews, and just swipe to remove them one by one. You can free up a considerable amount of space by removing them.

######################################

- PREFERENCE FILES REMOVAL: when you uninstall a Cydia tweak or app, its preference files are usually not removed. This tool allows you to delete preference files that you don't need anymore.
Furthermore, it can be useful to troubleshoot broken configuration files, or reset tweaks settings to their default values.

######################################

- MOVE FONTS FOLDER: iCleaner can move the huge "Fonts" folder to/from the System partition, which has very limited space. Please note that no space is gained during this process, as the folder is just moved.
Of course, fonts will still be readable by iOS. The folder is moved and then replaced with a symbolic link to the new location, so everything will work just as before. You can bring it back to its original location by re-running this tool.

######################################

More Info:
--------------------------------------
Check the project website (http://exilecom.altervista.org/cydia/icleaner) for further info, FAQs, troubleshooting or to display the full changelog.


Support:
--------------------------------------
If you have questions or issues about iCleaner, just visit the project page (http://exilecom.altervista.org/cydia/icleaner) and check the "Troubleshooting" section, or send me an email at "exile@live.it".


Disclaimer:
--------------------------------------
IMPORTANT - PLEASE READ: by using iCleaner (referred to as "the Software"), you agree to be bound to these terms between you and Ivano Bilenchi (referred to as "the Licensor"). If you do not agree to these terms, do not use the software product.

The Software is provided "AS IS", without warranty of any kind, including without limitation the warranties of merchantability, fitness for a particular purpose and non-infringement.
The Licensor makes no warranty that the Software is free of defects or is suitable for any particular purpose.
In no event shall the Licensor be responsible for loss or damages arising from the installation or use of the Software, including but not limited to any indirect, punitive, special, incidental or consequential damages of any character including, without limitation, device failure or malfunction, or any other commercial damages or losses.
