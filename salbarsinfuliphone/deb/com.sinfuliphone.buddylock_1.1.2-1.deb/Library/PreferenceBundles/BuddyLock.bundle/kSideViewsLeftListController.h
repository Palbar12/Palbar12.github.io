#import <Preferences/Preferences.h>
#import <UIKit/UIKit.h>

@interface kSideViewsLeftListController : PSListController <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, retain) NSMutableArray *sideViews;
@property (nonatomic, retain) NSMutableDictionary *buddyLockSettings;
@property (nonatomic, retain) NSMutableDictionary *dict;
@property (nonatomic, retain) UITableView *tblView;
@property (nonatomic, retain) NSIndexPath *lastIndexPath;

- (id)initForContentSize:(CGSize)contentSize;
- (id)navigationTitle;
- (id)title;
@end